/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function changeuser(){
    location.href = 'clear.html';
}
function changelocations(){
     location.href = "locations1.html";
}

function notifictionopen(){
    debugger;
   app.router.navigate("/myNotifications/");
}
