var routes = [
    {
        path: '/subdepts/',
        url: './subdeptsf7.html'
    },
    {
        path: '/dashboardmenu/',
        url: './dashboardmenuf7.html'
    },
    {
        path: '/locations/',
        url: './locations1.html'
    },
    {
        path: '/dashboardmenubuttons/',
        url: './dashboardmenubuttonsf7.html'
    },
    {
        path: '/settings/',
        url: './settings7.html'
    },
    {
        path:'/selectdoctors/',
        url:'./selectdoctorsf7.html'
    },
    {
        path:'/disfirstscreen/',
        url:'./disfirstscreenf7.html'
    },
    {
        path:'/dissecondscreen/',
        url:'./dissecondscreenf7.html'
    },
    {
        path:'/webreportsf7/',
        url:'./webreportsf7.html'
    }
    ,
    {
        path:'/myNotifications/',
        url:'./NotificationDashboard2.html'
    },
    {
        path:'/reportPDF/',
        url:'./ReportPDF.html'
    },
    {
        path:'/Dis2OrderF7/',
        url:'./Dis2OrderF7.html'
    },
    {
       path:'/EntrenceF7/',
       url:'./EntrenceF7.html' 
    },
    {
        path:'/DrillDashboardF7/',
        url:'./DrillDashboardF7.html/'
    }

];
