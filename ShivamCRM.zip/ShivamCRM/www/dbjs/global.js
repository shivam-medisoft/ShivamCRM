/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
var portnum=" ";
if(localStorage.ipadrs== undefined ||localStorage.ipadrs == "")
{
  
    portnum=""; 
}

else
{
    portnum=localStorage.ipadrs;
}
 
