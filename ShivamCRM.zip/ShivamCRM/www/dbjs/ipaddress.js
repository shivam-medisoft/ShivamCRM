/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function geturl(){
    var url = $('#txtUrl').val();
    localStorage.ipadrs = url;
}
