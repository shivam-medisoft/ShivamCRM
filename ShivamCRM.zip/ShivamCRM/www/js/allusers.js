/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function getAllusers() {
//    debugger;
//    if (localStorage.iphostname !== null || localStorage.iphostname !="") {
//        var ipsel = localStorage.ipsel.split("@@@");
//        var iport = localStorage.ipport.split("@@@");
//        var iphostname = localStorage.iphostname.split("@@@");
//        var ipusername = localStorage.ipusername.split("@@@");
//        var iphospname = localStorage.iphospname.split("@@@");
//        var ippassword = localStorage.ippassword.split("@@@");
//        localStorage.ipsel = "";
//        localStorage.ipport = "";
//        localStorage.iphostname = "";
//        localStorage.ipusername = "";
//        localStorage.iphospname = "";
//        localStorage.ippassword = "";
//        localStorage.setItem("ipsel", JSON.stringify(ipsel));
//        localStorage.setItem("ipport", JSON.stringify(iport));
//        localStorage.setItem("iphostname", JSON.stringify(iphostname));
//        localStorage.setItem("ipusername", JSON.stringify(ipusername));
//        localStorage.setItem("ippassword", JSON.stringify(ippassword));
//        localStorage.setItem("iphospname", JSON.stringify(iphospname));
//    }
}


